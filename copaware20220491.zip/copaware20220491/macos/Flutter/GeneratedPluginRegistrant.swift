//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import sqflite

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  SqflitePlugin.register(with: registry.registrar(forPlugin: "SqflitePlugin"))
}
