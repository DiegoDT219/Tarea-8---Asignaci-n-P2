import 'package:flutter/material.dart';

class IncidentDetailScreen extends StatelessWidget {
  /// Objeto de tipo Incidencia que contiene los detalles del incidente a mostrar.
  final Incident incident;

  /// Constructor de la clase IncidentDetailScreen que recibe un objeto Incidencia como parámetro obligatorio.
  IncidentDetailScreen({required this.incident});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalle de Incidencia'), // Título de la barra de aplicaciones
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Título:', // Etiqueta para el título del incidente
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10.0),
              Text(incident.title), // Muestra el título del incidente
              SizedBox(height: 20.0),
              Text(
                'Fecha:', // Etiqueta para la fecha del incidente
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10.0),
              Text(incident.date.toString()), // Muestra la fecha del incidente
              SizedBox(height: 20.0),
              Text(
                'Descripción:', // Etiqueta para la descripción del incidente
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10.0),
              Text(incident.description), // Muestra la descripción del incidente
              SizedBox(height: 20.0),
              if (incident.photo != null)
                Image.file(incident.photo), // Muestra la foto del incidente si existe
              SizedBox(height: 20.0),
              if (incident.audio != null)
                AudioPlayer(
                  url: incident.audio, // Muestra la grabación de audio del incidente si existe
                ),
            ],
          ),
        ),
      ),
    );
  }
}
