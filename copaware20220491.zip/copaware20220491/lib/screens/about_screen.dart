import 'package:flutter/material.dart';

/// Pantalla Acerca de que muestra información sobre el oficial.
class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Acerca de'), // Título de la barra de aplicaciones
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// Muestra la foto del oficial si está disponible
            if (officerPhoto != null)
              Image.asset(
                'assets/images/officer.jpg', // Ruta por defecto a la imagen del oficial
              ),
            SizedBox(height: 20.0),
            // ... resto de la pantalla Acerca de (asumiendo que hay más contenido)
          ],
        ),
      ),
    );
  }
}
