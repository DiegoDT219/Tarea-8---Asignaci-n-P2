import 'package:flutter/material.dart';
import 'package:app_name/screens/incident_detail_screen.dart';

/// Pantalla principal que muestra la lista de incidencias registradas.
class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Incidencias'), // Título de la barra de aplicaciones
      ),
      body: FutureBuilder(
        /// Obtiene una lista futura de objetos Incidencia mediante la función DatabaseService.getIncidents().
        future: DatabaseService.getIncidents(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            List<Incident> incidents = snapshot.data; // Convierte los datos del snapshot a una lista de Incidentes
            return ListView.builder(
              itemCount: incidents.length, // Define el número de elementos en la lista basado en la longitud de la lista de incidentes
              itemBuilder: (context, index) {
                return IncidentListTile(incident: incidents[index]); // Muestra un widget IncidentListTile para cada incidencia
              },
            );
          } else {
            return CircularProgressIndicator(); // Muestra un indicador de progreso circular mientras se cargan los datos
          }
        },
      ),
    );
  }
}
